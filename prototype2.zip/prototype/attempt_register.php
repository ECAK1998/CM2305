
<?php
//session stuff
session_start();
?>

<?php
//Connect to database
$dbservername = "csmysql.cs.cf.ac.uk";
$dbusername = "group10.2017";
$dbpassword = "vRfSPZW9NN7nek";
$dbname = "group10_2017";

// Create connection
$conn = new mysqli($dbservername, $dbusername, $dbpassword,$dbname);

// Check connection 
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?> 

<?php
//get post variables
$userid = $_POST['userid'];
$usertype = $_POST['usertype'];
$password = $_POST['password'];

//create password hash
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

//insert values into database
$sql = "INSERT INTO Users (UserID, UserType, SaltedPassword) VALUES ('".$userid."', '".$usertype."', '".$hashed_password."')";


if ($conn->query($sql) === TRUE) {
    //redirect to sign in page
    header("Location: sign-in.php");
    die();

} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>