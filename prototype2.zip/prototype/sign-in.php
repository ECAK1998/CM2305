
<?php
//session stuff
session_start();
?>


<!DOCTYPE html>
<html>
<head>

<meta charset="utf-8">
<link rel="stylesheet" href="style.css">
<title>Grouping Central</title>
</head>
<body>

<h1>Sign-in</h1>
<noscript>You don't have javascript!</noscript>

<script type="text/javascript">
	function validateInput(){
		var userid = document.forms["signinForm"]["userid"].value;
		var password = document.forms["signinForm"]["password"].value;
		var regexPattern;

		regexPattern = /^[A-Z]{1}[0-9]{7}$/; //is like c1622200

		if (regexPattern.test(userid) == false) {
			alert("A User ID must start with a captial letter followed by 7 digits.");
			return false;
		}

		//password regex is taken from following link:
		//https://stackoverflow.com/questions/2370015/regular-expression-for-password-validation
		regexPattern = /^.*(?=.{8,})(?=.*[a-zA-Z])(?=.*\d)(?=.*[!#$%&?"]).*$/;

		if (regexPattern.test(password) == false) {
			alert("A Password must contain 8 characters and at least one number, one letter and one unique character such as '!#$%&?' except white space.");
			return false;
		}
		regexPattern = /^$|\s+/

		//check for white space, might remove this later as passwords will be salted anyway?
		if (regexPattern.test(password) == true) {
			alert("A Password must contain 8 characters and at least one number, one letter and one unique character such as '!#$%&?' except white space.");
			return false;
		}
	}

</script>

    <form name="signinForm" onsubmit="return validateInput()" action="attempt_sign-in.php" method="post" class="loginform cf">
    	<ul>
			<li><label for="userid">User ID:</label>
			<input type="text" name="userid" size="15" placeholder="User ID" required></li>
			<li><label for="password">Password:</label>
			<input type="Password" name="password" size="15" placeholder="Password" required></li>
			<li><input type="submit"></li>
		</ul>
	</form>
  


</body>
</html>