
<?php
//session stuff
session_start();
?>

<?php
//Connect to database
$dbservername = "csmysql.cs.cf.ac.uk";
$dbusername = "group10.2017";
$dbpassword = "vRfSPZW9NN7nek";
$dbname = "group10_2017";

// Create connection
$conn = new mysqli($dbservername, $dbusername, $dbpassword,$dbname);

// Check connection 
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?> 

<!DOCTYPE html>
<html>
<head>

<meta charset="utf-8">
<link rel="stylesheet" href="style.css">
<title>Grouping Central</title>
</head>
<body>

<h1>User Details</h1>
<?php
//check user type
$usertype = $_SESSION["usertype"];
$userid = $_SESSION["userid"];

//display different info depending on user type
switch ($usertype) {
	case "Student":
		//print out user id and user type
		echo "<p>User ID: ".$userid."</p>";
		echo "<p>User Type: ".$usertype."</p>";
		//get details from appropriate database
		$sql = "SELECT * FROM Students WHERE UserID = '".$userid."'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
		    // output data of each row
		    $row = $result->fetch_assoc();
			echo "<p>Name: ".$row["StudentName"]."</p>";
			echo "<p>Tutor Name: ".$row["TutorName"]."</p>";
			echo "<p>Course: ".$row["Course"]."</p>";
			echo "<p>Year: ".$row["Year"]."</p>";
			echo "<p>Email: ".$row["Email"]."</p>";
			echo "<p>Group: ".$row["GroupNumber"]."</p>";
		}else{
			echo "<p>Name:</p>";
			echo "<p>Tutor Name:</p>";
			echo "<p>Course:</p>";
			echo "<p>Year:</p>";
			echo "<p>Email:</p>";
			echo "<p>Group:</p>";
		    }
		break;
	case "Lecturer":
		//print out user id and user type
		echo "<p>User ID: ".$userid."</p>";
		echo "<p>User Type: ".$usertype."</p>";
		//get details from appropriate database
		$sql = "SELECT * FROM Lecturers WHERE UserID = '".$userid."'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
		    // output data of each row
		    $row = $result->fetch_assoc();
			echo "<p>Name: ".$row["LecturerName"]."</p>";
			echo "<p>Course: ".$row["Course"]."</p>";
			echo "<p>Email: ".$row["Email"]."</p>";
		}else{
			echo "<p>Name:</p>";
			echo "<p>Course:</p>";
			echo "<p>Email:</p>";
		    }
		break;
	case "Moderator":
		//print out user id and user type
		echo "<p>User ID: ".$userid."</p>";
		echo "<p>User Type: ".$usertype."</p>";
		//get details from appropriate database
		$sql = "SELECT * FROM Moderators WHERE UserID = '".$userid."'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
		    // output data of each row
		    $row = $result->fetch_assoc();
			echo "<p>Name: ".$row["ModeratorName"]."</p>";
			echo "<p>Email: ".$row["Email"]."</p>";
		}else{
			echo "<p>Name:</p>";
			echo "<p>Email:</p>";
		    }
		break;
	default:
		echo "Error: ".$usertype." is not a valid UserType.";

}
?>

<h1>Options</h1>
<p><a href="sign-out.php">Sign-out</a></p>
<p><a href="edit-user-page.php">Edit Details</a></p>
<p><a href="groupManagement.php">Groups</a></p>
<p><a href="file.php">Files</a></p>

</body>
</html>