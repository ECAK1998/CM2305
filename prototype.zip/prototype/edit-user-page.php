
<?php
//session stuff
session_start();
?>

<?php
//Connect to database
$dbservername = "csmysql.cs.cf.ac.uk";
$dbusername = "group10.2017";
$dbpassword = "vRfSPZW9NN7nek";
$dbname = "group10_2017";

// Create connection
$conn = new mysqli($dbservername, $dbusername, $dbpassword,$dbname);

// Check connection 
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?> 
<!DOCTYPE html>
<html>
<head>

<meta charset="utf-8">
<link rel="stylesheet" href="style.css">
<title>Grouping Central</title>
</head>
<body>

<h1>User Details</h1>
<?php
//check user type
$usertype = $_SESSION["usertype"];
$userid = $_SESSION["userid"];

//display different info depending on user type
switch ($usertype) {
	case "Student":
		//print out user id and user type
		echo "<p>User ID: ".$userid."</p>";
		echo "<p>User Type: ".$usertype."</p>";

		//make for with post metho with relevant fields
		echo '<form  action="attempt_edit.php" method="post">
	<p>Name: <input type="text" name="name" size="32" maxlength="32"></p>
	<p>Tutor Name: <input type="text" name="tutorname" size="32" maxlength="32"></p>
	<p>Course: <input type="text" name="course" size="32" maxlength="32"></p>
	<p>Year: <input type="number" name="year" size="2"></p>
	<p>Email: <input type="email" name="email"></p>
	<p>Group: <input type="number" name="groupnumber" size="2"></p>
	<p><input type="submit"></p>
	</form>';
		break;
	case "Lecturer":
		//print out user id and user type
		echo "<p>User ID: ".$userid."</p>";
		echo "<p>User Type: ".$usertype."</p>";
		echo '<form  action="attempt_edit.php" method="post">
	<p>Name: <input type="text" name="name" size="32" maxlength="32"></p>
	<p>Course: <input type="text" name="course" size="32" maxlength="32"></p>
	<p>Email: <input type="email" name="email"></p>
	<p><input type="submit"></p>
	</form>';

		break;
	case "Moderator":
		//print out user id and user type
		echo "<p>User ID: ".$userid."</p>";
		echo "<p>User Type: ".$usertype."</p>";
		echo '<form  action="attempt_edit.php" method="post">
	<p>Name: <input type="text" name="name" size="32" maxlength="32"></p>
	<p>Email: <input type="email" name="email"></p>
	<p><input type="submit"></p>
	</form>';
		break;
}
?>



<h1>Options</h1>
<p><a href="sign-out.php">Sign-out</a></p>
<p><a href="user-page.php">Go Back</a></p>
</body>
</html>

