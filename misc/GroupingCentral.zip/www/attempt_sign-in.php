
<?php
//session stuff
session_start();
?>

<?php
//Connect to database
$dbservername = "csmysql.cs.cf.ac.uk";
$dbusername = "group10.2017";
$dbpassword = "vRfSPZW9NN7nek";
$dbname = "group10_2017";

// Create connection
$conn = new mysqli($dbservername, $dbusername, $dbpassword,$dbname);

// Check connection 
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?> 

<?php
//get post variables
$userid = $_POST['userid'];
$password = $_POST['password'];

//check userid against database

$sql = "SELECT * FROM Users WHERE UserID = '".$userid."'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    $row = $result->fetch_assoc();
	if(password_verify($password, $row["SaltedPassword"])){
		//set Session variables for userID and userType
		$_SESSION["userid"] = $userid;
		$_SESSION["usertype"] = $row["UserType"];
		//redirect to user page
		header("Location: user-page.php");
		die();
	} else {
		//redirect to sign in page which has 'incorrect password'
		header("Location: sign-in_incorrect-password.php");
		die();
	}
    
} else {
    //redirect to register page with user does not exist message
    header("Location: register_user-not-found.php");
	die();
}
$conn->close();

?>