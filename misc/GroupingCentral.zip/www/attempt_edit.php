
<?php
//session stuff
session_start();
?>

<?php
//Connect to database
$dbservername = "csmysql.cs.cf.ac.uk";
$dbusername = "group10.2017";
$dbpassword = "vRfSPZW9NN7nek";
$dbname = "group10_2017";

// Create connection
$conn = new mysqli($dbservername, $dbusername, $dbpassword,$dbname);

// Check connection 
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?> 

<?php
//get user ID and user type
$usertype = $_SESSION["usertype"];
$userid = $_SESSION["userid"];

switch ($usertype) {
	case "Student":
		//get all post variables
		$studentname = $_POST['name'];
		$tutorname = $_POST['tutorname'];
		$course = $_POST['course'];
		$year = $_POST['year'];
		$email = $_POST['email'];
		$groupnumber = $_POST['groupnumber'];
		//access correct database according to user type
		$sql = "SELECT * FROM Students WHERE UserID = '".$userid."'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
			//update
			$sql = "UPDATE Students SET studentname='{$studentname}', tutorname='{$tutorname}', course='{$course}', year='{$year}', email='{$email}', groupnumber='{$groupnumber}' WHERE userid='{$userid}'";
			if ($conn->query($sql) === TRUE) {
				echo "Record updated successfully";
			} else {
				echo "Error updating record: " . $conn->error;
			}

			$conn->close();
		} else {
			//insert details if no record exists
			$sql = "INSERT INTO Students (userid, studentname, tutorname, course, year, email, groupnumber)
			VALUES ('".$userid."','".$studentname."','".$tutorname."','".$course."','".$year."','".$email."','".$groupnumber."')";

			if ($conn->query($sql) === TRUE) {
				echo "New record created successfully";
			} else {
				echo "Error: " . $sql . "<br>" . $conn->error;
			}

			$conn->close();
		}
		break;
	case "Lecturer":
		$lecturername = $_POST['name'];
		$course = $_POST['course'];
		$email = $_POST['email'];

		$sql = "SELECT * FROM Lecturers WHERE UserID = '".$userid."'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
					//update
			$sql = "UPDATE Lecturers SET lecturername='{$lecturername}', course='{$course}', email='{$email}' WHERE userid='{$userid}'";
			if ($conn->query($sql) === TRUE) {
				echo "Record updated successfully";
			} else {
				echo "Error updating record: " . $conn->error;
			}

			$conn->close();
		} else {
			//insert details if no record exists
			$sql = "INSERT INTO Lecturers (userid, lecturername, course, email)
			VALUES ('{$userid}', '{$lecturername}', '{$course}', '{$email}')";

			if ($conn->query($sql) === TRUE) {
				echo "New record created successfully";
			} else {
				echo "Error: " . $sql . "<br>" . $conn->error;
			}

			$conn->close();
		}
		break;
	case "Moderator":
		//do something
	$moderatorname = $_POST['name'];
		$course = $_POST['course'];
		$email = $_POST['email'];

		$sql = "SELECT * FROM Moderators WHERE UserID = '".$userid."'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
					//update
			$sql = "UPDATE Moderators SET moderatorname='{$moderatorname}', email='{$email}' WHERE userid='{$userid}'";
			if ($conn->query($sql) === TRUE) {
				echo "Record updated successfully";
			} else {
				echo "Error updating record: " . $conn->error;
			}

			$conn->close();
		} else {
			//insert details if no record exists
			$sql = "INSERT INTO Moderators (userid, moderatorname, email)
			VALUES ('{$userid}', '{$moderatorname}', '{$email}')";

			if ($conn->query($sql) === TRUE) {
				echo "New record created successfully";
			} else {
				echo "Error: " . $sql . "<br>" . $conn->error;
			}

			$conn->close();
		}
		break;
}



//redirect to userpage with the (hopefully) updated details
   header("Location: user-page.php");
	die();

?>
